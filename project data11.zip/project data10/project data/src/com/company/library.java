package com.company;

import java.util.LinkedList;

public class library {
    public static LinkedList<member> listOfMembers = new LinkedList<>();
    public static LinkedList<loan> listOFLoans = new LinkedList<>();
    public static Object dequeuedReq;

}

